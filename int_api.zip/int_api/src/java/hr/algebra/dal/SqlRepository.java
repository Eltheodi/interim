package hr.algebra.dal;

import hr.algebra.model.AppUser;
import hr.algebra.model.Pet;
import hr.algebra.model.PetSpecies;
import hr.algebra.model.PostedContent;
import hr.algebra.model.ResponseToPost;

import hr.algebra.model.UserType;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.sql.DataSource;

public class SqlRepository implements Repository {
    
    private static final String AUTHENTICATE_USER = "{ CALL uspAuthenticateUser (?, ?, ?) }";
    private static final String UPDATE_USER_PROFILE = "{ CALL uspUpdateUserProfile (?, ?, ?, ? , ?) }";
    private static final String GET_USER_DATA = "{ CALL uspGetUserData (?, ?) }";
    private static final String GET_USER_DATA_ID = "{ CALL uspGetUserDataID (?) }";
    private static final String GET_PETS = "{ CALL uspGetPets () }";
    private static final String GET_POSTS = "{ CALL uspGetPostedContent () }";
    private static final String DELETE_POST = "{ CALL uspDeletePost (?) }";
    private static final String GET_ALL_USERS = "{ CALL uspGetAllUsers () }";
    
    private static final String GET_RESPONSES = "{ CALL getResponseToPost () }";
    
    @Override
    public boolean AuthenticateUser(String username, String password) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(AUTHENTICATE_USER)) {
            
            stmt.setString(1, username);
            stmt.setString(2, password);
            stmt.registerOutParameter(3, Types.INTEGER);
            
            stmt.executeUpdate();
            int id = stmt.getInt(3);
            if (id < 1) {
                return false;
            } else {
                return true;
            }
            
        }
    }

//    private static final String AUTHENTICATE_USER = "{ CALL uspAuthenticateUser (?, ?, ?) }";
//    private static final String CREATE_USER = "{ CALL uspCreateUser (?, ?,?,?, ?) }";
//    private static final String LOGIN_LOGGING = "{ CALL uspInsertLoggingDetails (?, ?) }";
//    private static final String GET_LOGS = "{ CALL uspGetLogs () }";
//    private static final String GET_PRODUCTS = "{ CALL uspGetProducts () }";
//    private static final String GET_COMPLETE_PURCHASE_HISTORY = "{ CALL uspGetCompletePurchaseHistory () }";
//    private static final String NEW_PURCHASE = "{ CALL uspNewPurchase (?,?) }";
//    private static final String NEW_PURCHASE_ITEM = "{ CALL uspNewPurchaseItem (?,?) }";
//
//    @Override
//    public int CheckUserLogin(String email, String password) throws Exception {
//
//        DataSource dataSource = DataSourceSingleton.getInstance();
//        try (Connection con = dataSource.getConnection();
//                CallableStatement stmt = con.prepareCall(CHECK_USER_LOGIN)) {
//
//            stmt.setString(1, email);
//            stmt.setString(2, password);
//            stmt.registerOutParameter(3, Types.INTEGER);
//
//            stmt.executeUpdate();
//            return stmt.getInt(3);
//        }
//
//    }
//
//    /**
//     *
//     * @param id
//     * @return
//     * @throws Exception
//     */
//    @Override
//    public Optional<AppUser> GetUserData(int id) throws Exception {
//
//        DataSource dataSource = DataSourceSingleton.getInstance();
//        Connection con = null;
//        AppUser p = null;
//        try {
//            con = dataSource.getConnection();
//            CallableStatement stmt = con.prepareCall(GET_USER_DATA);
//            stmt.setInt(1, id);
//            ResultSet rs = stmt.executeQuery();
//            while (rs.next()) {
//                p = new AppUser(
//                        rs.getInt("IDAppUser"),
//                        rs.getString("FirstName"),
//                        rs.getString("LastName"),
//                        rs.getString("Email"),
//                        rs.getString("Pwd"),
//                        new UserType(rs.getInt("IDUserType"), rs.getString("TypeName")));
//            }
//            con.close();
//        } finally {
//            if (con != null) {
//                con.close();
//            }
//        }
//
//        if (p != null) {
//            return Optional.of(p);
//        }
//        return Optional.empty();
//    }
//
//    @Override
//    public int createUser(AppUser p) throws Exception {
//        DataSource dataSource = DataSourceSingleton.getInstance();
//        try (Connection con = dataSource.getConnection();
//                CallableStatement stmt = con.prepareCall(CREATE_USER)) {
//
//            stmt.setString(1, p.getFirstName());
//            stmt.setString(2, p.getLastName());
//            stmt.setString(3, p.getEmail());
//            stmt.setString(4, p.getPwd());
//            stmt.registerOutParameter(5, Types.INTEGER);
//            stmt.executeUpdate();
//            int id = stmt.getInt(5);
//            return id;
//        }
//    }
//
//    @Override
//    public void saveLoginData(AppUser loggedInUser, String ipAddress) {
//
//        DataSource dataSource = DataSourceSingleton.getInstance();
//        try (Connection con = dataSource.getConnection();
//                CallableStatement stmt = con.prepareCall(LOGIN_LOGGING)) {
//
//            stmt.setInt(1, loggedInUser.getIdAppUser());
//            stmt.setString(2, ipAddress);
//            stmt.executeUpdate();
//        } catch (SQLException ex) {
//            Logger.getLogger(SqlRepository.class.getName()).log(Level.SEVERE, null, ex);
//        }
//
//    }
//
//    @Override
//    public List<LoggingInfo> getLogs() {
//        List<LoggingInfo> logsList = new ArrayList<>();
//
//        DataSource dataSource = DataSourceSingleton.getInstance();
//        try (Connection con = dataSource.getConnection();
//                CallableStatement stmt = con.prepareCall(GET_LOGS)) {
//
//            ResultSet rs = stmt.executeQuery();
//           
//            while (rs.next()) {
//
//                LoggingInfo log = new LoggingInfo();
//
//                log.setIdLoggingInfo(Integer.parseInt(rs.getString("IDLoggingInfo")));
//                log.setLoggingTimestamp(rs.getString("LoggingTimestamp"));
//                log.setAddressIP(rs.getString("AddressIP"));
//                AppUser user = new AppUser(
//                        Integer.parseInt(rs.getString("IDAppUser")), 
//                                rs.getString("FirstName"),
//                                rs.getString("LastName"),
//                                rs.getString("Email"),
//                                rs.getString("Pwd"),
//                                new UserType(Integer.parseInt(rs.getString("IDUserType")), rs.getString("TypeName")));
//                log.setLoggedUser(user);
//                        
//            
//                logsList.add(log);
//            }
//
//        } catch (SQLException ex) {
//            Logger.getLogger(SqlRepository.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return logsList;
//    }
//
//    @Override
//    public List<Product> getProducts() {
//         List<Product> productsList = new ArrayList<>();
//
//        DataSource dataSource = DataSourceSingleton.getInstance();
//        try (Connection con = dataSource.getConnection();
//                CallableStatement stmt = con.prepareCall(GET_PRODUCTS)) {
//
//            ResultSet rs = stmt.executeQuery();
//           
//            while (rs.next()) {
//
//                Product p = new Product();
//
//                p.setIdProduct(Integer.parseInt(rs.getString("IDProduct")));
//                p.setAvailableQuantity(Integer.parseInt(rs.getString("AvailableQuantity")));
//                p.setPrice(Double.parseDouble(rs.getString("Price")));
//                p.setDetails(rs.getString("Details"));
//                p.setProductName(rs.getString("ProductName"));
//                Category cat = new Category(
//                        Integer.parseInt(rs.getString("IDCategory")), 
//                                rs.getString("CategoryName"));
//                p.setCategory(cat);
//                        p.setImage(rs.getString("ProductImage"));
//            
//                productsList.add(p);
//            }
//
//        } catch (SQLException ex) {
//            Logger.getLogger(SqlRepository.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return productsList;
//    }
//
//    @Override
//    public int insertNewPurchase(int id) {
//        DataSource dataSource = DataSourceSingleton.getInstance();
//        
//        int purchaseID = 0;
//        try (Connection con = dataSource.getConnection();
//                CallableStatement stmt = con.prepareCall(NEW_PURCHASE)) {
//
//            stmt.setInt(1, id);
//            stmt.registerOutParameter(2, Types.INTEGER);
//
//            stmt.executeUpdate();
//            purchaseID= stmt.getInt(2);
//        } catch (SQLException ex) {
//            Logger.getLogger(SqlRepository.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return purchaseID;
//    }
//
//    @Override
//    public void insertNewPurchaseItem(int purchaseID, Product p) {
// DataSource dataSource = DataSourceSingleton.getInstance();
//        try (Connection con = dataSource.getConnection();
//                CallableStatement stmt = con.prepareCall(NEW_PURCHASE_ITEM)) {
//
//            stmt.setInt(1, purchaseID);
//            stmt.setInt(2, p.getIdProduct());
//            stmt.executeUpdate();
//        } catch (SQLException ex) {
//            Logger.getLogger(SqlRepository.class.getName()).log(Level.SEVERE, null, ex);
//        }
//    }
//
//    
//    
//    
//        
//    
//    @Override
//    public List<PurchaseHistory> getCompletePurchaseHistory() {
//      
//      List<PurchaseHistory> purchaseList = new ArrayList<>();
//      List<PurchaseItem> purchaseItems = new ArrayList<>();
//      AppUser user = new AppUser();
//        DataSource dataSource = DataSourceSingleton.getInstance();
//        try (Connection con = dataSource.getConnection();
//                CallableStatement stmt = con.prepareCall(GET_COMPLETE_PURCHASE_HISTORY)) {
//
//            ResultSet rs = stmt.executeQuery();
//           
//            while (rs.next()) {
//
//                PurchaseHistory p = new PurchaseHistory();
//
//                p.setIdPurchase(Integer.parseInt(rs.getString("IDPurchase")));
//                PurchaseItem item = new PurchaseItem();
//                Product pr= new Product();
//                pr.setProductName(rs.getString("ProductName"));
//                item.setProduct(pr);
//                purchaseItems.add(item);
//                        
//               p.setPurchaseItems(purchaseItems);
//                
//                user.setIdAppUser(Integer.parseInt(rs.getString("UserID")));
//                user.setFirstName(rs.getString("FirstName"));
//                user.setLastName(rs.getString("LastName"));
//                user.setEmail(rs.getString("Email"));
//                user.setUserType(new UserType(Integer.parseInt(rs.getString("UserTypeID")), rs.getString("TypeName")));
//                
//                p.setPurchaseTime(rs.getString("PurchaseTime"));
//                p.setUser(user);
//             
//            
//            
//                purchaseList.add(p);
//            }
//
//        } catch (SQLException ex) {
//            Logger.getLogger(SqlRepository.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return purchaseList;
//    }
    @Override
    public <Optional> AppUser GetUserData(String username, String password) throws Exception {
        
        DataSource dataSource = DataSourceSingleton.getInstance();
        Connection con = null;
        AppUser p = null;
        try {
            con = dataSource.getConnection();
            
            CallableStatement stmt = con.prepareCall(GET_USER_DATA);
            stmt.setString(1, username);
            stmt.setString(2, password);
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                
                p = new AppUser(
                        rs.getInt("IDAppUser"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("Email"),
                        rs.getString("Username"),
                        rs.getString("ContactNumber"),
                        new UserType(rs.getInt("IDUserType"), rs.getString("TypeName"))
                );
            }
            con.close();
        } finally {
            if (con != null) {
                con.close();
            }
        }
        
        return p;
        
    }
    
    @Override
    public void UpdateProfileData(int idAppUser, String email, String firstName, String lastName, String contactNumber) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(UPDATE_USER_PROFILE)) {
            
            stmt.setInt(1, idAppUser);
            stmt.setString(2, email);
            stmt.setString(3, firstName);
            stmt.setString(4, lastName);
            stmt.setString(5, contactNumber);
            
            stmt.executeUpdate();
        }
    }
    
    @Override
    public <Optional> AppUser GetUserData(int id) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        Connection con = null;
        AppUser p = null;
        try {
            con = dataSource.getConnection();
            
            CallableStatement stmt = con.prepareCall(GET_USER_DATA_ID);
            stmt.setInt(1, id);
            
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                
                p = new AppUser(
                        rs.getInt("IDAppUser"),
                        rs.getString("FirstName"),
                        rs.getString("LastName"),
                        rs.getString("Email"),
                        rs.getString("Username"),
                        rs.getString("ContactNumber"),
                        new UserType(rs.getInt("IDUserType"), rs.getString("TypeName"))
                );
            }
            con.close();
        } finally {
            if (con != null) {
                con.close();
            }
        }
        
        return p;
    }
    
    @Override
    public ArrayList<Pet> getPetData() throws Exception {
        ArrayList<Pet> petList = new ArrayList<>();
        
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(GET_PETS)) {
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                Pet p = new Pet();
                p.setIdPet(Integer.parseInt(rs.getString("IDPet")));
                p.setPetName(rs.getString("PetName"));
                
                p.setPetWeight(Integer.parseInt(rs.getString("PetWeight")));
                p.setYearOfBirth(Integer.parseInt(rs.getString("YearOfBirth")));
                p.setOwnerID(Integer.parseInt(rs.getString("OwnerID")));
                p.setAddedInfo(rs.getString("AddedInfo"));
                PetSpecies ps = new PetSpecies();
                ps.setIdPetSpecies(Integer.parseInt(rs.getString("IDPetSpecies")));
                ps.setSpeciesName(rs.getString("SpeciesName"));
                
                p.setPetSpecies(ps);
                
                petList.add(p);
                
            }
            
        }
        return petList;
    }
    
    @Override
    public ArrayList<PostedContent> getAllPosts() throws Exception {
        ArrayList<PostedContent> allPosts = new ArrayList<>();
        
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(GET_POSTS)) {
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                PostedContent p = new PostedContent();
                p.setIdPostedContent(Integer.parseInt(rs.getString("IDPostedContent")));
                p.setTitle(rs.getString("Title"));
                p.setContent(rs.getString("Content"));
                p.setTimeCreated(rs.getString("TimeCreated"));
                
                p.setLocationOf(rs.getString("LocationOf"));
                
                p.setContentOwnerID(Integer.parseInt(rs.getString("ContentOwnerID")));
                
                AppUser user = GetUserData(p.getContentOwnerID());
                p.setContentOwner(user);
                allPosts.add(p);
                
            }
            
        }
        return allPosts;
    }
    
    @Override
    public void deletePost(Integer postID) throws Exception {
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(DELETE_POST)) {
            
            stmt.setInt(1, postID);
            stmt.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(SqlRepository.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public ArrayList<AppUser> getAllUsers() throws Exception {
        
        ArrayList<AppUser> allUsers = new ArrayList<>();
        
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(GET_ALL_USERS)) {
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                AppUser user = new AppUser();
                user.setIdAppUser(Integer.parseInt(rs.getString("IDAppUser")));
                user.setUsername(rs.getString("Username"));
                user.setContactNumber(rs.getString("ContactNumber"));
                user.setEmail(rs.getString("Email"));
                user.setFirstName(rs.getString("FirstName"));
                user.setLastName(rs.getString("LastName"));
                
                UserType userType = new UserType(Integer.parseInt(rs.getString("IDUserType")), rs.getString("TypeName"));
                user.setUserType(userType);
                
                allUsers.add(user);
                
            }
            
        }
        return allUsers;
        
    }
    
    @Override
    public ArrayList<ResponseToPost> getAllResponses() throws Exception {
        
        ArrayList<ResponseToPost> allResponses = new ArrayList<>();
        
        DataSource dataSource = DataSourceSingleton.getInstance();
        try (Connection con = dataSource.getConnection();
                CallableStatement stmt = con.prepareCall(GET_RESPONSES)) {
            
            ResultSet rs = stmt.executeQuery();
            
            while (rs.next()) {
                
                ResponseToPost response = new ResponseToPost();
                
                response.setIdResponse(Integer.parseInt(rs.getString("IDResponse")));
                response.setMoreInfo(rs.getString("MoreInfo"));
                
                Pet p = new Pet();                
                p.setIdPet(Integer.parseInt(rs.getString("IDPet")));
                p.setPetName(rs.getString("PetName"));
                
                p.setPetWeight(Integer.parseInt(rs.getString("PetWeight")));
                p.setYearOfBirth(Integer.parseInt(rs.getString("YearOfBirth")));
                p.setOwnerID(Integer.parseInt(rs.getString("OwnerID")));
                p.setAddedInfo(rs.getString("AddedInfo"));
                PetSpecies ps = new PetSpecies();
                ps.setIdPetSpecies(Integer.parseInt(rs.getString("IDPetSpecies")));
                ps.setSpeciesName(rs.getString("SpeciesName"));
                p.setPetSpecies(ps);
                AppUser user = new AppUser();
                user.setIdAppUser(Integer.parseInt(rs.getString("IDAppUser")));
                user.setUsername(rs.getString("Username"));
                user.setContactNumber(rs.getString("ContactNumber"));
                user.setEmail(rs.getString("Email"));
                user.setFirstName(rs.getString("FirstName"));
                user.setLastName(rs.getString("LastName"));
                
                UserType userType = new UserType(Integer.parseInt(rs.getString("IDUserType")), rs.getString("TypeName"));
                user.setUserType(userType);
                p.setPetOwner(user);
                response.setPet(p); 
                
                
                PostedContent pc = new PostedContent();
                pc.setIdPostedContent(Integer.parseInt(rs.getString("IDPostedContent")));
                pc.setTitle(rs.getString("Title"));
                pc.setContent(rs.getString("Content"));
                pc.setTimeCreated(rs.getString("TimeCreated"));
                
                pc.setLocationOf(rs.getString("LocationOf"));
                
                pc.setContentOwnerID(Integer.parseInt(rs.getString("ContentOwnerID")));
                
                AppUser contentOwner = GetUserData(pc.getContentOwnerID());
                pc.setContentOwner(contentOwner);
                response.setPost(pc);
                
                
                allResponses.add(response);
                
            }
            
        }
        return allResponses;
    }
    
}
