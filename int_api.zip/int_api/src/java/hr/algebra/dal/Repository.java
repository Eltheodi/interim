package hr.algebra.dal;

import hr.algebra.model.AppUser;
import hr.algebra.model.Pet;
import hr.algebra.model.PostedContent;
import hr.algebra.model.ResponseToPost;
import java.util.ArrayList;
import java.util.Optional;
import java.util.List;

public interface Repository {

    public boolean AuthenticateUser(String username, String password) throws Exception;

//
//    int CheckUserLogin(String username, String password) throws Exception;
//
//    int createUser(AppUser p) throws Exception;
//
//    public void saveLoginData(AppUser loggedInUser, String ipAddress);
//
//    public Optional<AppUser> GetUserData(int id) throws Exception;
//
//    public List<LoggingInfo> getLogs();
//    
//    public List<Product> getProducts();
//
//    public int insertNewPurchase(int id);
//
//    public void insertNewPurchaseItem(int purchaseID,Product p);
//
//    public List<PurchaseHistory> getCompletePurchaseHistory();
    public <Optional> AppUser GetUserData(String username, String password) throws Exception;

    public <Optional> AppUser GetUserData(int id) throws Exception;

    public void UpdateProfileData(int idAppUser, String email, String firstName, String lastName, String contactNumber) throws Exception;

    public ArrayList<Pet> getPetData() throws Exception;

    public ArrayList<PostedContent> getAllPosts()throws Exception;

    public void deletePost(Integer postID)throws Exception;

    public ArrayList<AppUser> getAllUsers()throws Exception;

    public ArrayList<ResponseToPost> getAllResponses() throws Exception;

}
