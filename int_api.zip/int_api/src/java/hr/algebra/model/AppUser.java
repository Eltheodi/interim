/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Katarina
 */
public class AppUser {
    
    private int idAppUser;

    public int getIdAppUser() {
        return idAppUser;
    }

    public void setIdAppUser(int idAppUser) {
        this.idAppUser = idAppUser;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public UserType getUserType() {
        return userType;
    }

    public void setUserType(UserType userType) {
        this.userType = userType;
    }

    public LocalDateTime getActiveUntil() {
        return activeUntil;
    }

    public void setActiveUntil(LocalDateTime activeUntil) {
        this.activeUntil = activeUntil;
    }


    private String firstName, lastName, email, pwd, username, contactNumber;
    private ArrayList<Pet> petDonors;

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public ArrayList<Pet> getPetDonors() {
        return petDonors;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public AppUser(int idAppUser, String firstName, String lastName, String email, String username, String contactNumber, UserType userType) {
        this.idAppUser = idAppUser;
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.username = username;
        this.contactNumber = contactNumber;
        this.userType = userType;
    }

    public void setPetDonors(ArrayList<Pet> petDonors) {
        this.petDonors = petDonors;
    }


    private UserType userType;
    private LocalDateTime activeUntil;

    public AppUser() {
    }

  
    @Override
    public String toString() {
        return  firstName + " " + lastName + ", email: " + email;
    }
    
    
    


    
    
}
