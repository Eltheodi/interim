/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model;

/**
 *
 * @author Katarina
 */
public class Pet {

    public int getIdPet() {
        return idPet;
    }
    
    
    private int idPet, yearOfBirth, petWeight;
    private String petName, addedInfo;
    private PetSpecies petSpecies;
    private int ownerID; 
    private AppUser petOwner;

    public AppUser getPetOwner() {
        return petOwner;
    }

    public void setPetOwner(AppUser petOwner) {
        this.petOwner = petOwner;
    }

    public int getOwnerID() {
        return ownerID;
    }

    public void setOwnerID(int ownerID) {
        this.ownerID = ownerID;
    }
    public void setIdPet(int idPet) {
        this.idPet = idPet;
    }

    public Pet() {
    }

    public Pet(int idPet, int yearOfBirth, int petWeight, String petName, String addedInfo, PetSpecies petSpecies) {
        this.idPet = idPet;
        this.yearOfBirth = yearOfBirth;
        this.petWeight = petWeight;
        this.petName = petName;
        this.addedInfo = addedInfo;
        this.petSpecies = petSpecies;
    }

    public int getYearOfBirth() {
        return yearOfBirth;
    }

    public void setYearOfBirth(int yearOfBirth) {
        this.yearOfBirth = yearOfBirth;
    }

    public int getPetWeight() {
        return petWeight;
    }

    public void setPetWeight(int petWeight) {
        this.petWeight = petWeight;
    }

    public String getPetName() {
        return petName;
    }

    public void setPetName(String petName) {
        this.petName = petName;
    }

    public String getAddedInfo() {
        return addedInfo;
    }

    public void setAddedInfo(String addedInfo) {
        this.addedInfo = addedInfo;
    }

    public PetSpecies getPetSpecies() {
        return petSpecies;
    }

    public void setPetSpecies(PetSpecies petSpecies) {
        this.petSpecies = petSpecies;
    }

    @Override
    public String toString() {
        return "Pet{" + "petName=" + petName + ", petSpecies=" + petSpecies + '}';
    }
    
    
}
