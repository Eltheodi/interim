/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model;

/**
 *
 * @author Katarina
 */
public class PostedContent {
    private int idPostedContent;
    private String title, content, locationOf, timeCreated;
    private AppUser contentOwner; 

    public AppUser getContentOwner() {
        return contentOwner;
    }

    public void setContentOwner(AppUser contentOwner) {
        this.contentOwner = contentOwner;
    }
    
    public String getTimeCreated() {
        return timeCreated;
    }

    public void setTimeCreated(String timeCreated) {
        this.timeCreated = timeCreated;
    }
    
    private int contentOwnerID;

    public PostedContent() {
    }

    public int getIdPostedContent() {
        return idPostedContent;
    }

    
    public void setIdPostedContent(int idPostedContent) {
        this.idPostedContent = idPostedContent;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getLocationOf() {
        return locationOf;
    }

    public void setLocationOf(String locationOf) {
        this.locationOf = locationOf;
    }

    public int getContentOwnerID() {
        return contentOwnerID;
    }

    public void setContentOwnerID(int contentOwnerID) {
        this.contentOwnerID = contentOwnerID;
    }

    public PostedContent(int idPostedContent, String title, String content, String locationOf, int contentOwnerID) {
        this.idPostedContent = idPostedContent;
        this.title = title;
        this.content = content;
        this.locationOf = locationOf;
        this.contentOwnerID = contentOwnerID;
    }
    
    
}
