/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.model;

/**
 *
 * @author Katarina
 */
public class PetSpecies {

    public void setIdPetSpecies(int idPetSpecies) {
        this.idPetSpecies = idPetSpecies;
    }
 
    
    private int idPetSpecies;
    private String speciesName;

    public PetSpecies() {
    }

    public PetSpecies(int idPetSpecies, String speciesName) {
        this.idPetSpecies = idPetSpecies;
        this.speciesName = speciesName;
    }

    public String getSpeciesName() {
        return speciesName;
    }

    public void setSpeciesName(String speciesName) {
        this.speciesName = speciesName;
    }

    @Override
    public String toString() {
        return speciesName;
    }
    
    
}
