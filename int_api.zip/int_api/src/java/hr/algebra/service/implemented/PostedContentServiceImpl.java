/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.service.implemented;

import hr.algebra.dal.Repository;
import hr.algebra.dal.RepositoryFactory;
import hr.algebra.model.PostedContent;
import hr.algebra.service.PostedContentService;
import java.util.ArrayList;

/**
 *
 * @author Katarina
 */
public class PostedContentServiceImpl implements PostedContentService {

    private Repository repo = null;

    public PostedContentServiceImpl() throws Exception {
        repo = RepositoryFactory.getRepository();

    }

    @Override
    public ArrayList<PostedContent> getAllPosts() throws Exception {
        ArrayList<PostedContent> allPosts = repo.getAllPosts();
        return allPosts;
    }

    @Override
    public ArrayList<PostedContent> getUsersPosts(int idAppUser) throws Exception {
        ArrayList<PostedContent> allPosts = getAllPosts();
        ArrayList<PostedContent> userPosts = new ArrayList<>();

        for (PostedContent post : allPosts) {
            if (post.getContentOwnerID()==idAppUser) {
                userPosts.add(post);
            }
        }

        return userPosts;

    }

    @Override
    public void deletePost(Integer postID) throws Exception {

        repo.deletePost(postID);


    }

}
