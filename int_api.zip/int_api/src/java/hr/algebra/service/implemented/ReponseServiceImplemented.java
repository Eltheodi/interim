/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.service.implemented;

import hr.algebra.dal.Repository;
import hr.algebra.dal.RepositoryFactory;
import hr.algebra.model.ResponseToPost;
import hr.algebra.service.ResponseService;
import java.util.ArrayList;

/**
 *
 * @author Katarina
 */
public class ReponseServiceImplemented implements ResponseService {

    private Repository repo = null;


    
    public ReponseServiceImplemented() throws Exception {
            repo = RepositoryFactory.getRepository();

    }

    
    
    
    @Override
    public ArrayList<ResponseToPost> getAllResponses() throws Exception {
       
    return repo.getAllResponses();
        
        
    }

    @Override
    public ArrayList<ResponseToPost> getResponsesForPost(int postID) throws Exception {
        ArrayList<ResponseToPost> allResponses = getAllResponses();
                ArrayList<ResponseToPost> responses = getAllResponses();

        
        for (ResponseToPost r : allResponses) {
            if (r.getPost().getIdPostedContent() == postID) {
                responses.add(r);
            }
        }
        
        return responses;
    }
    
}
