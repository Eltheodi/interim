/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.service.implemented;

import hr.algebra.dal.Repository;
import hr.algebra.dal.RepositoryFactory;
import hr.algebra.model.AppUser;
import hr.algebra.model.Pet;
import hr.algebra.service.UserService;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author Katarina
 */
public class UserServiceImpl implements UserService {

    private Repository repo = null;

    public UserServiceImpl() throws Exception {
        repo = RepositoryFactory.getRepository();

    }

    @Override
    public Optional<AppUser> getLogin(String username, String password) throws Exception {
        System.out.println("login");
        boolean AuthenticateUser = repo.AuthenticateUser(username, password);
        System.out.println("aaa");

        if (AuthenticateUser) {
            AppUser user = repo.GetUserData(username, password);
            return Optional.of(user);

        } else {
            return Optional.empty();
        }

    }

    @Override
    public void updateProfile(int idAppUser, String email, String firstName, String lastName, String contactNumber) throws Exception {

        repo.UpdateProfileData(idAppUser, email, firstName, lastName, contactNumber);
    }

    @Override
    public Optional<AppUser> getUserData(int id) throws Exception {

        AppUser reqUser = repo.GetUserData(id);
        return Optional.of(reqUser);

    }

    @Override
    public ArrayList<Pet> getPetData() throws Exception {

        ArrayList<Pet> petData = repo.getPetData();
        return petData;
    }

    @Override
    public ArrayList<Pet> getUserPetData(int idAppUser) throws Exception {
        List<Pet> petData = getPetData();
        ArrayList<Pet> usersPet = new ArrayList<>();
        for (Pet pet : petData) {
            if (pet.getOwnerID() == idAppUser) {
                usersPet.add(pet);
            }
        }
        return usersPet;
    }

    @Override
    public ArrayList<AppUser> getAllUsers() throws Exception {
        ArrayList<AppUser> usersData = repo.getAllUsers();
        for (AppUser appUser : usersData) {
            ArrayList<Pet> pets = getUserPetData(appUser.getIdAppUser());
            appUser.setPetDonors(pets);
        }
        
        
        return usersData;
    



    }

}
