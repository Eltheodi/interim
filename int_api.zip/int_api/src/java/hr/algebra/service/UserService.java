/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.service;

import hr.algebra.model.AppUser;
import hr.algebra.model.Pet;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 *
 * @author Katarina
 */

public interface UserService {
    public Optional<AppUser> getLogin(String email, String password) throws Exception; 
    public Optional<AppUser> getUserData(int id) throws Exception; 


    public void updateProfile(int idAppUser, String email, String firstName, String lastName, String contactNumber) throws Exception;
    
    
    
    public ArrayList<AppUser> getAllUsers() throws Exception; 

    public ArrayList<Pet> getPetData() throws Exception; 
    public ArrayList<Pet> getUserPetData(int idAppUser) throws Exception; 


}
