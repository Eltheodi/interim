/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.service;

import hr.algebra.model.Pet;
import hr.algebra.model.PostedContent;
import java.util.ArrayList;

/**
 *
 * @author Katarina
 */
public interface PostedContentService {
    public ArrayList<PostedContent> getAllPosts() throws Exception; 
    public ArrayList<PostedContent> getUsersPosts(int idAppUser) throws Exception; 

    public void deletePost(Integer postID) throws Exception; 
}
