/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra.service;

import hr.algebra.model.Pet;
import hr.algebra.model.ResponseToPost;
import java.util.ArrayList;

/**
 *
 * @author Katarina
 */
public interface ResponseService {
    
    
        public ArrayList<ResponseToPost> getAllResponses() throws Exception; 
        public ArrayList<ResponseToPost> getResponsesForPost(int postID) throws Exception; 

    
}
