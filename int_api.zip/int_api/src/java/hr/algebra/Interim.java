/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hr.algebra;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import hr.algebra.model.AppUser;
import hr.algebra.model.PostedContent;
import hr.algebra.service.PostedContentService;
import hr.algebra.service.UserService;
import hr.algebra.service.implemented.PostedContentServiceImpl;
import hr.algebra.service.implemented.UserServiceImpl;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;

/**
 * REST Web Service
 *
 * @author Katarina
 */
@Path("interim")
public class Interim {

    @Context
    private UriInfo context;

    /**
     * Creates a new instance of Interim
     */
    public Interim() {
    }

    /**
     * Retrieves representation of an instance of hr.algebra.Interim
     *
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_JSON)
    public String getJson() {

        String jsonString = "";
        try {
            GsonBuilder builder = new GsonBuilder();
            builder.setPrettyPrinting();
            Gson gson = builder.create();

            UserService us = new UserServiceImpl();
            ArrayList<AppUser> allUsers = us.getAllUsers();

            for (AppUser user : allUsers) {
                jsonString += gson.toJson(user);
            }
        } catch (Exception ex) {
            Logger.getLogger(Interim.class.getName()).log(Level.SEVERE, null, ex);
        }
        return jsonString;
    }

    /**
     * PUT method for updating or creating an instance of Interim
     *
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_JSON)
    public void putJson(String content) {
    }

    @GET
    @Path("/posts/")

    @Produces(MediaType.APPLICATION_JSON)
    public String getData() {

        String jsonString = "";
        try {
            GsonBuilder builder = new GsonBuilder();
            builder.setPrettyPrinting();
            Gson gson = builder.create();

            UserService us = new UserServiceImpl();
            PostedContentService pcs = new PostedContentServiceImpl();
            ArrayList<PostedContent> allPosts = pcs.getAllPosts();

            for (PostedContent post : allPosts) {
                jsonString += gson.toJson(post);
            }
        } catch (Exception ex) {
            Logger.getLogger(Interim.class.getName()).log(Level.SEVERE, null, ex);
        }
        return jsonString;
    }

    @POST
    @Path("/post/{id}")

    @Produces(MediaType.APPLICATION_JSON)
    public String getPost(@PathParam("id") int id) {

        String jsonString = "";
        try {
            GsonBuilder builder = new GsonBuilder();
            builder.setPrettyPrinting();
            Gson gson = builder.create();

            UserService us = new UserServiceImpl();

            PostedContentService pcs = new PostedContentServiceImpl();
            ArrayList<PostedContent> allPosts = pcs.getAllPosts();

            for (PostedContent post : allPosts) {

                if (post.getContentOwner().getIdAppUser() == id) {
                    jsonString += gson.toJson(post);
                }

            }
        } catch (Exception ex) {
            Logger.getLogger(Interim.class.getName()).log(Level.SEVERE, null, ex);
        }
        return jsonString;
    }

    @POST
    @Path("/email/{mail}")

    @Produces(MediaType.APPLICATION_JSON)
    public String sendEmail(@PathParam("mail") String user_mail) {
        
        List<String> mailovi = new ArrayList();
        
        mailovi.add(user_mail);
        mailovi.add("katarina.ozanic@gmail.com");
        
        String text = "Poštovani.....katarina <3";
        String status = "";
        try {
           
            for (String mail : mailovi) {
                
            sendEmailViaGmail(mail, text);
            }
            
            status = "Success";
        } catch (Exception e) {
            status = "Failure";
        }
        return status;
    }

//    @POST
//    @Path("/login/")
//    @Produces(MediaType.APPLICATION_JSON)
//    public String getLogin(@RequestParam String username, @RequestParam String pwd) {
//
//        // 1. validiraj username i pwd; 
//        //hr.algebra.validator.LoginRequestValidator
//        //metoda validate(username, password); 
//        //u metodi se nalazi: 
//        //uzmi username, trim it***, izbaci sve specijalne znakove, provjeri duljinu***, provjeri da nije javascript
//        //isto za pwd
//        // 2. dohvati korisnika prema useru i pwdu
//        //servisni sloj, pa data layer
//        // 3. vrati objekt AppUser kroz json
//        return "";
//    }
//    @POST
//    @Path("/invite/{id}")
//    @Produces(MediaType.APPLICATION_JSON)
//    public String sendInvite(@PathParam("id") NoviObjektUvjetiPoziva obj) {
//
//        
//        
//        
//        // 1. validiraj obj: stavku po stavku
//        // 2. dohvati sve id-eve (korisnika) koji udovoljavaju uvjetima poziva
//                
//        // 3. posalji notifikaciju korisnicima 
//        // 4. for each idkorisnik: posalji email
//        // (opcionalno) 5.  posalji push notifikaciju, posalji sms,
//        
//        
//        
//        
//        
//        
//        
//        
//        String jsonString = "";
//        try {
//            GsonBuilder builder = new GsonBuilder();
//            builder.setPrettyPrinting();
//            Gson gson = builder.create();
//
//            UserService us = new UserServiceImpl();
//
//            PostedContentService pcs = new PostedContentServiceImpl();
//            ArrayList<PostedContent> allPosts = pcs.getAllPosts();
//
//            for (PostedContent post : allPosts) {
//
//                if (post.getContentOwner().getIdAppUser() == id) {
//                    jsonString += gson.toJson(post);
//                }
//
//            }
//        } catch (Exception ex) {
//            Logger.getLogger(Interim.class.getName()).log(Level.SEVERE, null, ex);
//        }
//        return jsonString;
//    }
    public void sendEmailViaGmail(String pEmailTo, String pMessageText) {

        // ovo je mail na koji saljes:
        String to = pEmailTo;

        // ovo je mail s kojeg se šalje, ovo se čak može i fejkat()
        String from = "katarina.ozanic@gmail.com";

        // google server za slanje mailova
        String host = "smtp.gmail.com";

        // Get system properties
        Properties properties = System.getProperties();

        // Setup mail server
        properties.put("mail.smtp.host", host);
        properties.put("mail.smtp.port", "465");
        properties.put("mail.smtp.ssl.enable", "true");
        properties.put("mail.smtp.auth", "true");

        // Get the Session object.// and pass username and password
        Session session = Session.getInstance(properties, new javax.mail.Authenticator() {

            // ovdje stavljaš svoj gmail account, i ako imas 2FA uključen, moraš kreirati app password	
            // ako je ukljucen 2FA, evo kakao kreirati app pass - https://support.google.com/accounts/answer/185833?visit_id=637984993346505266-3878848435&p=InvalidSecondFactor&rd=1
            // ako nemas ukljucen 2FA, onda samo stavis svoj gmail password
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication("ozanic.katarina@gmail.com", "uwqtbimuaeyhjcqo");
            }

        });

        // Used to debug SMTP issues
        session.setDebug(true);

        try {
            // Create a default MimeMessage object.
            MimeMessage message = new MimeMessage(session);

            // Set From: header field of the header.
            message.setFrom(new InternetAddress(from));

            // Set To: header field of the header.
            message.addRecipient(Message.RecipientType.TO, new InternetAddress(to));

            // Set Subject: header field
            // ovaj subject mozes ili zafiksat ili si ga poslat kroz parametar, kao i email, npr
            // npr Novi poziv za dobrovoljno darivanje krvi za ljubimce!
            message.setSubject("Nova poruka od INTERIM APP");

            // Now set the actual message
            message.setText(pMessageText);

            System.out.println("sending...");
            // Send message
            Transport.send(message);
            System.out.println("Sent message successfully....");
        } catch (Exception mex) {
            mex.printStackTrace();
        }
    }
}
